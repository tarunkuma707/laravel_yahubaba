-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2025 at 06:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `first_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `libraries`
--

CREATE TABLE `libraries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stu_id` bigint(20) UNSIGNED NOT NULL,
  `book` varchar(255) NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL COMMENT '1 for Return 0 for not Return'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(10, '2025_02_19_131814_create_students_table', 1),
(11, '2025_02_19_133258_create_libraries_table', 1),
(12, '2025_02_20_052939_update_library_table', 1),
(13, '2025_02_20_053318_update_library_table', 1),
(14, '2025_02_20_102059_create_users_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `age`, `email`, `address`, `city`, `phone`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Dominic Schmeler', 19, 'nthiel@grimes.net', '1678 Mabel Views Suite 850\nOscarbury, OR 83050', 'South Sheila', '931-959-1524', '\\W=?!,c6c#1b*dK&KP8A', '2025-02-20 05:04:51', '2025-02-20 05:04:51'),
(2, 'Mrs. Amy Cormier', 17, 'hartmann.javon@brown.com', '2040 Vandervort Pike\nEast Shayne, DE 30034', 'Jedediahhaven', '737.423.7355', 'E}+9Z?S*L?3L', '2025-02-20 05:04:52', '2025-02-20 05:04:52'),
(3, 'Ms. Dora Schroeder', 17, 'mcglynn.modesta@yahoo.com', '56286 Justyn Islands Apt. 381\nSchmitttown, CT 45278-1475', 'Port Madelinechester', '470.788.0669', '>-acBJ*O(~m)Cg', '2025-02-20 05:04:52', '2025-02-20 05:04:52'),
(4, 'Nestor Kiehn', 16, 'okuneva.kobe@beier.com', '7699 Tremblay Heights Apt. 495\nNorth Dane, ME 48749-6793', 'Vilmachester', '+1.636.278.4996', 'S%6:(=6},..=C}HA', '2025-02-20 05:04:52', '2025-02-20 05:04:52'),
(5, 'Irma Reinger V', 18, 'zfay@gmail.com', '20489 Carmella Cape\nJeremymouth, FL 31477-9062', 'South Kenny', '+1 (531) 643-3550', 'p[KCj&u', '2025-02-20 05:04:52', '2025-02-20 05:04:52'),
(6, 'Dr. Solon Fadel', 17, 'griffin.bernier@gmail.com', '81097 Rey Drives Suite 576\nWest Nameview, IN 85741', 'North Jaydenfurt', '1-815-389-3945', 'oi\"+hdP:BU_4(WM/', '2025-02-20 05:05:55', '2025-02-20 05:05:55'),
(7, 'Leonora Windler DDS', 19, 'viva62@hotmail.com', '73553 Jarred Trail Apt. 625\nPort Jacklynberg, NE 57344-2898', 'Raphaellemouth', '980-253-6434', '>;$P15Sz', '2025-02-20 05:05:55', '2025-02-20 05:05:55'),
(8, 'Virgie Mayert', 19, 'christ11@stokes.com', '55343 Shad Groves\nLuciousborough, NE 40431', 'Laneyfort', '1-470-936-5252', '\'Yu.=T/2a', '2025-02-20 05:05:55', '2025-02-20 05:05:55'),
(9, 'Alf Brown', 15, 'thea.pagac@yahoo.com', '760 Howe Trail Apt. 401\nNorth Russside, KY 35650', 'Reillymouth', '+12674844254', '$P~iQJ(IP', '2025-02-20 05:05:55', '2025-02-20 05:05:55'),
(10, 'Celia Powlowski', 18, 'clare46@gmail.com', '62146 Nikko Branch\nSouth Edmundborough, MT 92860-6608', 'Lake Guiseppe', '1-865-534-3548', 'w8=Xdp#', '2025-02-20 05:05:55', '2025-02-20 05:05:55'),
(11, 'Lavon Shanahan', 15, 'elian.kovacek@beahan.com', '2085 Conroy Inlet Apt. 588\nLebsackview, GA 30084', 'Lake Vern', '+1-430-508-7389', '=R1k4\"L', '2025-02-20 05:08:33', '2025-02-20 05:08:33'),
(12, 'Trystan Morar', 16, 'damore.janessa@gmail.com', '41798 Sage Junctions Suite 566\nAdanfort, PA 29522-2087', 'East Litzy', '+1-520-440-6463', 'teD;nq4{)X\'za', '2025-02-20 05:08:34', '2025-02-20 05:08:34'),
(13, 'Dr. Magdalen Johns', 15, 'sbernhard@schmitt.info', '621 Rhianna Turnpike Apt. 900\nSouth Lawsonhaven, MO 51424-1766', 'Blockton', '+1-617-948-3224', 'meOaMW}/Hi=*%.hyU', '2025-02-20 05:08:34', '2025-02-20 05:08:34'),
(14, 'Carol Kertzmann', 15, 'towne.joey@yahoo.com', '9152 Bahringer Spring\nNorth Aniyahtown, WV 97759', 'Klockoton', '+18582315193', '..5Vxc', '2025-02-20 05:08:34', '2025-02-20 05:08:34'),
(15, 'Tomasa Dickinson II', 15, 'jena.klein@schumm.biz', '84752 Lueilwitz Parkways\nLennaburgh, IN 74073', 'South Annamarieborough', '830.712.2548', '>%9uxz^Q(CRbmR\\\\F{V', '2025-02-20 05:08:34', '2025-02-20 05:08:34'),
(16, 'Clay O\'Conner MD', 17, 'aromaguera@casper.net', '72017 Olin Stream Suite 706\nNorth Khalil, NH 67882-3667', 'Hyattfurt', '385-314-0992', '8!$:@#l|2:LWba,Ly', '2025-02-20 05:09:33', '2025-02-20 05:09:33'),
(17, 'Berenice Cartwright II', 20, 'jordyn66@hermann.com', '408 Alvina Villages Apt. 052\nSouth Linnieland, MT 13315', 'Lake Marianeburgh', '678.866.8952', 'K3FhgAd`axg4nQ<%6.u~', '2025-02-20 05:09:33', '2025-02-20 05:09:33'),
(18, 'Kayley Dicki', 17, 'cesar.rowe@hand.org', '29320 Feest Inlet Suite 602\nJamarcushaven, AR 46263-9461', 'East Mollyland', '743-355-7530', 'eckhz2Ak~QTVn}', '2025-02-20 05:09:33', '2025-02-20 05:09:33'),
(19, 'Dr. Jaquelin Bergnaum', 17, 'kayla.mueller@hotmail.com', '98384 Karley Extensions Suite 774\nFredericview, DE 98138-6509', 'Serenabury', '307.414.9800', ':V=~m=5.cARZXUQ}q;g*', '2025-02-20 05:09:34', '2025-02-20 05:09:34'),
(20, 'Lance Huel', 18, 'bharber@medhurst.com', '424 Allen Route Apt. 498\nKeyonberg, GA 75689-2878', 'Lake Mary', '520-721-6609', '0]b}Kt7#H6Qe4', '2025-02-20 05:09:34', '2025-02-20 05:09:34'),
(21, 'Kaley Witting', 16, 'maybelle94@white.com', '35794 Morar Plains\nNew Consuelotown, FL 60704', 'Huelville', '+1.941.651.2815', ']e-3:@', '2025-02-20 05:13:11', '2025-02-20 05:13:11'),
(22, 'Laila Auer', 16, 'ugraham@gmail.com', '349 Crist Shoal\nCristshire, AR 11038-0312', 'Jeffereymouth', '(559) 368-5445', 'DGe|grzhuYF=s0', '2025-02-20 05:13:11', '2025-02-20 05:13:11'),
(23, 'Dr. Jalyn Conn', 15, 'nwolf@tremblay.net', '2389 Elmore Brook\nDarionchester, NY 73965', 'Hayesshire', '650.709.4869', '=3X8oOf', '2025-02-20 05:13:11', '2025-02-20 05:13:11'),
(24, 'Lenna Stroman', 19, 'millie.goldner@yahoo.com', '49891 Rosalee Radial Apt. 166\nWuckertville, HI 19410-9437', 'Mayertmouth', '+12135437908', 'a?i7~(zLhwU}JY', '2025-02-20 05:13:11', '2025-02-20 05:13:11'),
(25, 'Freeman Roob', 16, 'bnader@kulas.com', '6029 Easter Cape\nNorth Raphaelle, SC 78529-7388', 'North Sidmouth', '+1.934.745.7048', '5?h,m=Q.>A', '2025-02-20 05:13:11', '2025-02-20 05:13:11'),
(26, 'Dr. Bonita Lemke', 20, 'shannon.batz@cole.com', '71336 Kali Trace\nHellerfurt, TX 20410', 'Brekkeland', '+1.346.586.3168', '|@%{!Z=@y^=Q?+H', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(27, 'Nicole Nitzsche', 20, 'bogan.idella@gmail.com', '117 Eddie Centers Apt. 893\nEast Dexter, AR 29523-3282', 'East Devantown', '+14047163211', ':FQ/P$R=:|JK1.*#', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(28, 'Jasmin McCullough', 16, 'obogisich@ullrich.biz', '370 Mckayla Tunnel Suite 465\nEast Kirstinfort, AK 97519', 'East Jabarifort', '+1.743.921.4056', '/^xN2h+U_;&;u7', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(29, 'Althea Green', 20, 'trent.klein@gleason.com', '62789 Herzog Alley\nWest Sophiemouth, MN 55538', 'Buckridgefort', '+17635891954', 'd?*nnR2', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(30, 'Nikki Fadel', 16, 'reggie85@gmail.com', '9836 Jayde Mountain\nNew Bryonview, KS 06958', 'Waelchiview', '1-973-947-4454', 'Nw3tD/qdDv;\'9', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(31, 'Rita Leffler', 19, 'jensen.veum@hotmail.com', '5119 Lehner Creek\nNew Korbinshire, ID 60949-1404', 'East Tatetown', '857.966.2603', '\\5j$mB~#&;o9uP>QD', '2025-02-20 05:27:47', '2025-02-20 05:27:47'),
(32, 'Abe Hand', 18, 'william70@nader.com', '91779 Reynolds Port Suite 364\nEffertzville, TX 31601-4100', 'East Vidamouth', '1-929-936-0948', 'fW+z~^.p60_Im', '2025-02-20 05:27:47', '2025-02-20 05:27:47'),
(33, 'Dr. Damion Fisher', 19, 'mosciski.jason@yahoo.com', '469 Jessika Lodge\nNorth Lempi, AR 88259', 'Runolfsdottirshire', '484-737-8953', '%x7QQAN<P`0A8\"L6\'T', '2025-02-20 05:27:47', '2025-02-20 05:27:47'),
(34, 'Prof. Kris Hauck', 20, 'colten.bartell@dickens.com', '2228 Ernestina Spring\nNew Alysaville, ME 70993', 'Jadafurt', '+1.804.994.2673', '>3Y<V;[^p', '2025-02-20 05:27:47', '2025-02-20 05:27:47'),
(35, 'Mr. Bertrand Pollich', 17, 'johnston.talia@hotmail.com', '1263 Curtis Trail Apt. 040\nRoobfurt, GA 20841', 'New Yasmeen', '+1.252.876.4261', '\\hE{uP()T', '2025-02-20 05:27:48', '2025-02-20 05:27:48'),
(36, 'Matt Berge', 17, 'xdaugherty@hotmail.com', '2157 Andre Field Suite 617\nEast Marley, MN 20520', 'Tatumport', '320.339.0045', 'T*bGTS', '2025-02-20 05:29:27', '2025-02-20 05:29:27'),
(37, 'Dr. Leonel Padberg III', 19, 'kessler.kurt@gmail.com', '5166 Osinski Groves Suite 914\nBrianneborough, NY 12241', 'East Zacharyshire', '+1-713-994-4135', 'KU`a4{g+W@F;@', '2025-02-20 05:29:27', '2025-02-20 05:29:27'),
(38, 'Drew Hudson', 15, 'schiller.antwon@yahoo.com', '1703 Lela Streets\nJosianeton, NY 19867', 'Monteborough', '321.521.4028', 'egGJ75NFGV}', '2025-02-20 05:29:27', '2025-02-20 05:29:27'),
(39, 'Olin Hill', 20, 'loyce.hackett@mueller.org', '84788 Jenifer Mews Apt. 288\nVeumfurt, MO 08108-7773', 'Zulaufborough', '(256) 220-1315', '%^j0U#&(', '2025-02-20 05:29:27', '2025-02-20 05:29:27'),
(40, 'Onie Jacobi', 20, 'gutkowski.brent@kub.org', '53393 Blanda Street\nKennyland, AL 25696-0150', 'Vinceview', '847.692.5408', 'C8h]fFI|mu', '2025-02-20 05:29:27', '2025-02-20 05:29:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `age` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `age`, `city`, `created_at`, `updated_at`) VALUES
(1, 'Yahoobaba', 'yahoo@gmail.com', 18, 'Delhi', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(2, 'Salman Khan', 'salman@gmail.com', 18, 'Delhi', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(3, 'Amitabh bachan', 'amitabh@gmail.com', 18, 'Delhi', '2025-02-20 05:14:10', '2025-02-20 05:14:10'),
(5, 'Ashok', 'ashok@gmail.com', 18, 'Delhi', '2025-02-20 05:29:27', '2025-02-20 05:29:27'),
(6, 'Ishaq Khan', 'ishaq@gmail.com', 18, 'Delhi', '2025-02-20 05:29:27', '2025-02-20 05:29:27'),
(7, 'Abhishek bachan', 'abhished@gmail.com', 18, 'Delhi', '2025-02-20 05:29:27', '2025-02-20 05:29:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `libraries`
--
ALTER TABLE `libraries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `libraries_stu_id_foreign` (`stu_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_email_unique` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `libraries`
--
ALTER TABLE `libraries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
